<?php

// All Route
Route::get('/', 'ContactController@getIndex');
Route::get('admin/contacts/data', 'ContactController@getData');
Route::post('admin/contacts/store', 'ContactController@postStore');
Route::post('admin/contacts/update', 'ContactController@postUpdate');
Route::post('admin/contacts/detete', 'ContactController@postDelete');

