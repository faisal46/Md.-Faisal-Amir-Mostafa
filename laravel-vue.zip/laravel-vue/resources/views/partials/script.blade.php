<!-- Scripts -->
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="{{ asset('js/vue.js') }}"></script>
<script src="{{ asset('js/vue-resource.js') }}"></script>



