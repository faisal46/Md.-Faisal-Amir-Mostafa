<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="{{ url('/') }}">
            <img src="{{ asset('images/logo.jpg') }}" alt="Regfire Solutions LTD" />
        </a>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <h2 class="logotext">User Management System</h2>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <div class="clearfix">
                    <a class="btn btn-success" @click="create()">Add New Customer</a>
                </div>
            </ul>
        </div>
    </div>
</nav>