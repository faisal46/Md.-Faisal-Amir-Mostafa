<!--Footer-->
<div class="card footer">
    <footer class="card-body">
        <p class="text-center">User Management System | Design & Development By &copy; <strong>Regfire Solutions Ltd</strong></p>
    </footer>
</div>
<!--Footer End-->