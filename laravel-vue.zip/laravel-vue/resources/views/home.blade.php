@extends('layouts.master')

@section('content')
<div class="container" id="app">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-center">All Customer Information</h2>
                </div>

                <div class="card-body">
                 @include('partials.message')
                    <table class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NAME</th>
                                <th>EMAIL</th>
                                <th>PHONE</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="row in data">
                                <td>@{{ row.id }}</td>
                                <td>@{{ row.name }}</td>
                                <td>@{{ row.email }}</td>
                                <td>@{{ row.phone }}</td>
                                <td>
                                    <button @click="edit(row)" type="button" class="btn btn-xs btn-warning" title="Edit Record">Edit</button>

                                    <button @click="delData(row)" type="button" class="btn btn-xs btn-danger" title="Delete Record">Delete</button>
                                </td>
                            </tr>      
                        </tbody>
                    </table>  
                </div>  

                <!--modal start-->
                <!-- The Modal -->
                <div class="modal fade" id="modal">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">

                                <h4 class="modal-title">@{{ isInsert?'New Contact':'Edit Contact' }}</h4>

                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input class="form-control input-sm" type="text" v-model="Contact.name">
                                </div>

                                <div class="form-group">
                                    <label>Email</label>
                                    <input class="form-control input-sm" type="email" v-model="Contact.email">
                                </div>

                                <div class="form-group">
                                    <label>Phone</label>
                                    <input class="form-control input-sm" type="number" v-model="Contact.phone">
                                </div>

                            </div>

                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                                <button v-if="isInsert" type="button" class="btn btn-primary"
                                        @click="store(Contact)">Save
                                </button>

                                <button v-if="!isInsert" type="button" class="btn btn-primary"
                                        @click="update(Contact)">Update
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
                <!--modal end-->

            </div>
        </div>
    </div>


    <script>
        var csrtToken = '{{csrf_token()}}';
        var adminUrl = '{{url('admin')}}';

        var app = new Vue({
            el: '#app',
            data: {
                data: [],
                isInsert: true,
                Contact: {name: null, email: null, phone: null}
            },
            created: function () {
                this.init()
            },
            methods: {
                init: function () {
                    this.$http.get(adminUrl + '/contacts/data')
                            .then(function (res) {
                                this.data = res.data
                            })
                },
                create: function () {
                    this.isInsert = true,
                            this.Contact = {}
                    $('#modal').modal()
                },
                store: function (data) {
                    if (!confirm('Are you sure added a new customer?'))
                        return;
                    data._token = csrtToken;
                    this.$http.post(adminUrl + '/contacts/store', data)
                            .then(function (res) {
                                this.init()
                                $('#modal').modal('hide');
                                this.Contact = {}
                            })
                },
                edit: function (row) {
                    this.isInsert = false,
                            this.Contact = row;
                    $('#modal').modal();
                },
                update: function (data) {
                    if (!confirm('Are you sure update info?'))
                        return;
                    data._token = csrtToken;
                    this.$http.post(adminUrl + '/contacts/update', data)
                            .then(function (res) {
                                this.init()
                                $('#modal').modal('hide');
                                this.Contact = {}
                            })
                },
                delData: function (row) {
                    if (!confirm('Are you sure delete customer?'))
                        return;
                    row._token = csrtToken;
                    this.$http.post(adminUrl + '/contacts/detete', row)
                            .then(function (res) {
                                this.init()
                            })
                }
            }
        });
    </script>
    @endsection
