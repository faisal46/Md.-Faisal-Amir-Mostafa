<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <title>@yield('title', 'User Management System')</title>
        <!-- Styles -->
        @include('partials.style')
        @yield('stylesheet')
        <!-- Script -->
        @include('partials.script')   
    </head>
    <body> 
        <div id="app">
            @include('partials.header')  
            <main class="py-4">
                @yield('content')
            </main>
        </div>
        @include('partials.footer')
    </body>
</html>
