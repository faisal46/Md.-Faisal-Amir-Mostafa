<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/vue.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue-resource.js')); ?>"></script>



