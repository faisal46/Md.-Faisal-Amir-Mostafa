<?php if($errors->any()): ?>
    <div class="alert alert-danger">
    	 <button type="button" class="close" data-dismiss="alert">&times;</button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8">
	        <div class="alert alert-success">
    	       <p> <?php echo e(Session::get('success')); ?> </p>
            </div>
       </div>
      </div>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="alert alert-danger">
               <p> <?php echo e(Session::get('error')); ?> </p>
            </div>
       </div>
      </div>
    </div>
<?php endif; ?>