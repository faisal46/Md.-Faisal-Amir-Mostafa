<?php

namespace App\Http\Controllers;

use App\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct() {
        
    }

    public function getIndex() {
        return view('home');
    }

    public function getData() {
        return Contact::all();
    }

    public function postStore(Request $request) {
        $contact = new Contact();
        $contact->name = $request->name;
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->save();
        return ['success' => true, 'message' => 'Updated Successfully'];
    }

    public function postUpdate(Request $request) {
        if ($request->has('id')) {
            Contact::find($request->input('id'))->update($request->all());
            return ['success' => true, 'message' => 'Updated Successfully'];
        }
    }

    public function postDelete(Request $request) {
        Contact::find($request->input('id'))->delete();

        return ['success' => true, 'message' => 'Delete Successfully'];
    }

}
